package com.pscomp.autoapp.monstertaiming;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.pscomp.autoapp.monstertaiming.MTConstants.MTIndicator;

public class BaseActivity extends Activity  implements OnClickListener{
    public static final String TAG = "BaseActivity";

    /**
     * Button for go to back screen.
     */
    private Button mBtnBack = null;

    /**
     * Indicate your device name.<br/>
     * If you have any devices that are not supported,
     * this tv indicate "Unknown device".<br/>
     * Otherwise, indicate device name you have.
     */
    private TextView mTvDeviceName = null;

    /**
     * Indicate current setting type.<br/>
     * If you change one or more settings,
     * this tv indicate "User settings".<br/>
     * Otherwise, "Default settings."
     */
    private TextView mTvSettingType = null;

    protected Intent mBackIntent = new Intent();

    protected int mDeviceName = MTIndicator.DEVICE_UNKNOWN;

    protected int mSettingType = MTIndicator.TYPE_DEFAULT;

    /**
     * inflate all views on Activity.
     */
    protected void inflateViews() {
        mTvDeviceName = (TextView) findViewById(android.R.id.text1);
        mTvSettingType = (TextView) findViewById(android.R.id.text2);
        mBtnBack = (Button) findViewById(android.R.id.button1);
    }

    /**
     * set event listener all reactive views.
     */
    protected void setEventListeners() {
        mBtnBack.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setIndicator(mDeviceName, mSettingType);
    }

    protected void finishAfterSetResult(int resultCode) {
        setResult(resultCode);
        finish();
    }

    protected void finishAfterSetResult(int resultCode, Intent data) {
        setResult(resultCode, data);
        finish();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data != null) {
            int deviceName = data.getIntExtra(MTIndicator.KEY_DEVICES, MTIndicator.DEVICE_UNKNOWN);
            int settingType = data.getIntExtra(MTIndicator.KEY_TYPE, MTIndicator.TYPE_DEFAULT);
            setIndicator(deviceName, settingType);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    protected void setIndicator(int deviceName, int settingType) {
        mDeviceName = deviceName;
        mSettingType = settingType;
        if (mTvDeviceName != null) {
            mTvDeviceName.setText(MTIndicator.DEVICE_NAME[deviceName - MTIndicator.DEVICE_UNKNOWN]);
        }
        if (mTvSettingType != null) {
            mTvSettingType.setText(MTIndicator.TYPE_NAME[settingType - MTIndicator.TYPE_DEFAULT]);
        }
    }


    protected void setBackIntent(int deviceName, int settingType) {
        if (mBackIntent != null) {
            mBackIntent.putExtra(MTIndicator.KEY_DEVICES, deviceName);
            mBackIntent.putExtra(MTIndicator.KEY_TYPE, settingType);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onClick(View v) {
        if (v == null) {
            LogHelper.errLog(TAG, "Param 'v' is null. Skip 'onClick' method.");
            return;
        }
        if (v.getId() == android.R.id.button1) {
            finishAfterSetResult(RESULT_OK, mBackIntent);
        }
    }
}
