/** Automatically generated file. DO NOT MODIFY */
package com.pscomp.autoapp.monstertaiming;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}