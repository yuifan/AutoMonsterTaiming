package com.pscomp.autoapp.monstertaiming;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.pscomp.autoapp.monstertaiming.MTConstants.MTIndicator;
import com.pscomp.autoapp.monstertaiming.MTConstants.MTIntent;

public class HelloApplicationDialogActivity extends Activity implements OnClickListener {
    public static final String TAG = "HelloApplicationDialogActivity";

    private Button mBtnGoToNexusScreen = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean startExtra = false;
        try {
            startExtra = getIntent().getBooleanExtra("hello_start", false);
        } catch (NullPointerException npe) {
            npe.printStackTrace();
        }
        if (startExtra) {
            setContentView(R.layout.activity_hello_application_dialog);
            
            mBtnGoToNexusScreen = (Button) findViewById(R.id.btn_go_to_load_settings);
            mBtnGoToNexusScreen.setOnClickListener(this);
        } else {
            setContentView(R.layout.activity_hello_finish_dialog);
            
            mBtnGoToNexusScreen = (Button) findViewById(R.id.btn_return_to_main);
            mBtnGoToNexusScreen.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_go_to_load_settings) {
            Intent loadSettingIntent = new Intent();
            if (isAlreadyInit()) {
                loadSettingIntent.setAction(MTIntent.ACTION_LOAD_SETTINGS);
            } else {
                loadSettingIntent.setAction(MTIntent.ACTION_INIT_SETTINGS);
            }
            startActivity(loadSettingIntent);
            finish();
        } else if (v.getId() == R.id.btn_return_to_main) {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
    
    private boolean isAlreadyInit() {
        SharedPreferences sharedPrefs =
            PreferenceManager.getDefaultSharedPreferences(this);
        int currentSettings = sharedPrefs.getInt("current_setting", MTIndicator.DEVICE_UNKNOWN);
        return currentSettings != MTIndicator.DEVICE_UNKNOWN;
    }
}
