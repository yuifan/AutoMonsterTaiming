package com.pscomp.autoapp.monstertaiming;

import com.pscomp.autoapp.monstertaiming.MTConstants.MTIntent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class LoadSettingsDialogActivity extends Activity implements OnClickListener {
    public static final String TAG = "LoadSettingsDialogActivity";

    private Button mBtnLoadFirstSettings = null;
    private Button mBtnLoadSecondSettings = null;
    private Button mBtnLoadThirdSettings = null;
    private Button mBtnLoadUser1Settings = null;
    private Button mBtnLoadUser2Settings = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.activity_load_settings_dialog);
        
        mBtnLoadFirstSettings = (Button) findViewById(R.id.btn_load_first_settings);
        mBtnLoadFirstSettings.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        case R.id.btn_load_first_settings:
            Intent returnIntent = new Intent(MTIntent.ACTION_HELLO_APPLICATION);
            returnIntent.putExtra("hello_start", false);
            startActivity(returnIntent);
            finish();
            break;
        case R.id.btn_load_second_settings:
            
            break;
        case R.id.btn_load_third_settings:
            break;
        case R.id.btn_load_user1_settings:
            break;
        case R.id.btn_load_user2_settings:
            break;
        default:
            LogHelper.errLog(TAG, "Are you GOD?");
        }
    }
}
