package com.pscomp.autoapp.monstertaiming;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;

import com.pscomp.autoapp.monstertaiming.MTConstants.MTIntent;

public class AutoMainActivity extends BaseActivity {
    public static final String TAG = "AutoMainActivity";

    /**
     * Button for start basic setting screen.
     */
    private Button mBtnBasicSetting = null;

    /**
     * Button for start coordinate setting screen.
     */
    private Button mBtnCoordinateSetting = null;

    /**
     * Button for start save setting screen.
     */
    private Button mBtnSaveSetting = null;

    /**
     * Button for start load setting screen.
     */
    private Button mBtnLoadSetting = null;

    /**
     * Button for start autoplay.
     */
    private Button mBtnStartAutoplay = null;

    /**
     * Button for stop autoplay.
     */
    private Button mBtnStopAutoPlay = null;

    /**
     * Button for stop application.<br/>
     * <b>This function does not supported some devices.</b>
     */
    private Button mBtnStopApplication = null;
    
    private ProgressDialog mInitializeProgressDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto_main);

        initializeAppDataIfNeeded();

        inflateViews();
        setEventListeners();
    }

    /**
     * Initialize Data for application if needed.
     */
    private void initializeAppDataIfNeeded() {
        SharedPreferences sharedPrefs =
                PreferenceManager.getDefaultSharedPreferences(this);
        if (sharedPrefs.getBoolean("FirstExecute", true)) {
            
            if (!LogHelper.DEBUG) {
                sharedPrefs.edit().putBoolean("FirstExecute", false).commit();
            }
            
            mInitializeProgressDialog = ProgressDialog.show(this,
                    getString(R.string.txt_title_initialize_dialog),
                    getString(R.string.txt_text_initialize_dialog));
            mInitializeProgressDialog.setCancelable(false);
            
            new InitializeAsyncTask().execute();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    /**
     * inflate all views on Main Activity.
     */
    @Override
    protected void inflateViews() {
        mBtnBasicSetting = (Button) findViewById(R.id.btn_change_basic_settings);
        mBtnCoordinateSetting = (Button) findViewById(R.id.btn_change_coordinate_settings);
        mBtnSaveSetting = (Button) findViewById(R.id.btn_save_settings);
        mBtnLoadSetting = (Button) findViewById(R.id.btn_load_settings);
        mBtnStartAutoplay = (Button) findViewById(R.id.btn_start_autoplay);
        mBtnStopAutoPlay = (Button) findViewById(R.id.btn_stop_autoplay);
        mBtnStopApplication = (Button) findViewById(R.id.btn_stop_application);
    }

    /**
     * set event listener all reactive views.
     */
    @Override
    protected void setEventListeners() {
        mBtnBasicSetting.setOnClickListener(this);
        mBtnCoordinateSetting.setOnClickListener(this);
        mBtnSaveSetting.setOnClickListener(this);
        mBtnLoadSetting.setOnClickListener(this);
        mBtnStartAutoplay.setOnClickListener(this);
        mBtnStopAutoPlay.setOnClickListener(this);
        mBtnStopApplication.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        Intent intent = null;
        switch (v.getId()){
        case R.id.btn_change_basic_settings:
            intent = new Intent(MTIntent.ACTION_BASIC_SETTINGS);
            startActivityForResult(intent, MTConstants.REQ_CODE_MT);
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
            break;
        case R.id.btn_change_coordinate_settings:
            intent = new Intent(MTIntent.ACTION_COORDINATE_SETTINGS);
            startActivityForResult(intent, MTConstants.REQ_CODE_MT);
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
            break;
        case R.id.btn_save_settings:

            break;
        case R.id.btn_load_settings:

            break;
        case R.id.btn_start_autoplay:

            break;
        case R.id.btn_stop_autoplay:

            break;
        case R.id.btn_stop_application:

            break;
        default:
            LogHelper.errLog(TAG, "Could not found corresponding view.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
    
    class InitializeAsyncTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            initializeAppData();
            try {
                Thread.sleep(3000);
            } catch (InterruptedException ie) {
                if (LogHelper.DEBUG) {
                    ie.printStackTrace();
                }
            }
            return null;
        }
        
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            mInitializeProgressDialog.dismiss();
//            startActivityForResult(new Intent(MTIntent.ACTION_HELLO_APPLICATION), MTConstants.REQ_CODE_MT);
            /*
             * ���Ⱑ startActivityForResult �� ȣ��� �ʿ䰡 ���� �� ����.
             */
            Intent helloIntent = new Intent(MTIntent.ACTION_HELLO_APPLICATION);
            helloIntent.putExtra("hello_start", true);
            startActivity(helloIntent);
        }
    }
    
    private void initializeAppData() {
        initializeBasicSettingData();
        initializeCoordinateSettingData();
        initializeEtcSettingData();
    }
    
    private void initializeBasicSettingData() {
        
    }
    
    private void initializeCoordinateSettingData() {
        
    }
    
    private void initializeEtcSettingData() {
        
    }
}
