package com.pscomp.autoapp.monstertaiming;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.pscomp.autoapp.monstertaiming.MTConstants.MTIntent;

public class HelloApplicationDialogActivity extends Activity implements OnClickListener {
    public static final String TAG = "HelloApplicationDialogActivity";

    private Button mBtnGoToNexusScreen = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        boolean startExtra = false;
        try {
            startExtra = getIntent().getBooleanExtra("hello_start", false);
        } catch (NullPointerException npe) {
            npe.printStackTrace();
        }
        if (startExtra) {
            setContentView(R.layout.activity_hello_application_dialog);
            
            mBtnGoToNexusScreen = (Button) findViewById(R.id.btn_go_to_load_settings);
            mBtnGoToNexusScreen.setOnClickListener(this);
        } else {
            setContentView(R.layout.activity_hello_finish_dialog);
            
            mBtnGoToNexusScreen = (Button) findViewById(R.id.btn_return_to_main);
            mBtnGoToNexusScreen.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_go_to_load_settings) {
            startActivity(new Intent(MTIntent.ACTION_LOAD_SETTINGS));
            finish();
        } else if (v.getId() == R.id.btn_return_to_main) {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}
