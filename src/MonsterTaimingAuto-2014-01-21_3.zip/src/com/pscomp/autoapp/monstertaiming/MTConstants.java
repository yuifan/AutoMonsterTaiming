package com.pscomp.autoapp.monstertaiming;

public class MTConstants {
    public static final int REQ_CODE_MT = 0x1000;

    public static class MTIntent {
        public static final String ACTION_BASIC_SETTINGS = "com.pscomp.autoapp.ACTION_BASIC_SETTINGS";
        public static final String ACTION_COORDINATE_SETTINGS = "com.pscomp.autoapp.ACTION_COORDINATE_SETTINGS";
        public static final String ACTION_HELLO_APPLICATION = "com.pscomp.autoapp.ACTION_HELLO_APPLICATION";
        public static final String ACTION_LOAD_SETTINGS = "com.pscomp.autoapp.ACTION_LOAD_SETTINGS";
        public static final String ACTION_INIT_SETTINGS = "com.pscomp.autoapp.ACTION_INIT_SETTINGS";
    }

    public static class MTIndicator {
        public static final String KEY_DEVICES = "dev_name";

        public static final int DEVICE_UNKNOWN = 0x2000;
        public static final int DEVICE_NEXUS4 = DEVICE_UNKNOWN + 1;
        public static final int DEVICE_GALAXY_S3 = DEVICE_UNKNOWN + 2;
        public static final int DEVICE_GALAXY_S2_TM = DEVICE_UNKNOWN + 3;

        public static final String[] DEVICE_NAME = new String[] {
            "Unknown Device", "Nexus4", "GalaxyS3", "GalaxyS2-TM"
        };

        public static final String KEY_TYPE = "setting_type";
        public static final int TYPE_DEFAULT = 0x3000;
        public static final int TYPE_USER = TYPE_DEFAULT + 1;
        
        public static final String[] TYPE_NAME = new String[] {
            "Default Setting", "User Setting"
        };
    }
}
