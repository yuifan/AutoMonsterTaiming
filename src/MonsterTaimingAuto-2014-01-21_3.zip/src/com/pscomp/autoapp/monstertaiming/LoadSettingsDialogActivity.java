package com.pscomp.autoapp.monstertaiming;

import com.pscomp.autoapp.monstertaiming.MTConstants.MTIndicator;
import com.pscomp.autoapp.monstertaiming.MTConstants.MTIntent;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class LoadSettingsDialogActivity extends Activity implements OnClickListener {
    public static final String TAG = "LoadSettingsDialogActivity";

    private Button mBtnLoadFirstSettings = null;
    private Button mBtnLoadSecondSettings = null;
    private Button mBtnLoadThirdSettings = null;
    private Button mBtnLoadUser1Settings = null;
    private Button mBtnLoadUser2Settings = null;

    private boolean mIsAlreadyInit = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setIsAlreadyInit();
        setContentView(R.layout.activity_load_settings_dialog);
        mBtnLoadFirstSettings = (Button) findViewById(R.id.btn_load_first_settings);
        mBtnLoadFirstSettings.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        case R.id.btn_load_first_settings:
            loadSettings(MTIndicator.DEVICE_NEXUS4);
            break;
        case R.id.btn_load_second_settings:
            
            break;
        case R.id.btn_load_third_settings:
            break;
        case R.id.btn_load_user1_settings:
            break;
        case R.id.btn_load_user2_settings:
            break;
        default:
            LogHelper.errLog(TAG, "Are you GOD?");
        }
    }

    private void setIsAlreadyInit() {
        SharedPreferences sharedPrefs =
            PreferenceManager.getDefaultSharedPreferences(this);
        int currentSettings = sharedPrefs.getInt("current_settings", MTIndicator.DEVICE_UNKNOWN);
        mIsAlreadyInit = currentSettings != MTIndicator.DEVICE_UNKNOWN;
    }

    private boolean isAlreadyInit() {
//        return true;
        return mIsAlreadyInit;
    }

    /**
     * 
     */
    private void loadSettings(int settingValue) {
      if (isAlreadyInit()) {
          loadSettingsIfAceepted(settingValue);
          loadSettingsInner(settingValue);
      } else {
          loadSettingsInner(settingValue);
          Intent returnIntent = new Intent(MTIntent.ACTION_HELLO_APPLICATION);
          returnIntent.putExtra("hello_start", false);
          startActivity(returnIntent);
          finish();
      }
    }

    private void loadSettingsInner(int settingValue) {
        SharedPreferences sharedPrefs =
            PreferenceManager.getDefaultSharedPreferences(this);
        Editor editor = sharedPrefs.edit();
        editor.putInt("current_settings", settingValue);
        editor.putInt("current_type", MTIndicator.TYPE_DEFAULT);
        editor.commit();
    }

    private void loadSettingsIfAceepted(final int settingValue) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("���ǻ���");
        builder.setMessage("�������� ���� �����Ͱ� ���� �� �ҷ����⸦ �ϸ� �����Ͱ� �������ϴ�.\n�������� �ȵǴ� �����ʹ� ���� �����ͷ� �����ϰ� �����ϼ���.");
        builder.setPositiveButton("�����ϰ� ����", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                loadSettingsInner(settingValue);
                finish();
            }
        });
        builder.setNegativeButton("���", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                
            }
        });
        builder.create().show();
    }
}
