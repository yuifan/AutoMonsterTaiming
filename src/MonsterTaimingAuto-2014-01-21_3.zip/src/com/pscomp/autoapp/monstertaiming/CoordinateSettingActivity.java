package com.pscomp.autoapp.monstertaiming;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CoordinateSettingActivity extends BaseActivity {
    public static final String TAG = "AxisSettingActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_coordinate_setting);
        
        inflateViews();
        setEventListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void inflateViews() {
        super.inflateViews();
    }

    @Override
    protected void setEventListeners() {
        super.setEventListeners();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}
