package com.pscomp.autoapp.monstertaiming;

import android.util.Log;

public class LogHelper {
    public static final boolean DEBUG = true;

    public static final String BLANK_MESSAGE = "blank message";
    
    public static void errLog(String tag, String msg) {
        if (msg == null) {
            msg = BLANK_MESSAGE;
        }
        Log.e(tag, msg);
    }
    public static void dbgLog(String tag, String msg) {
        if (msg == null) {
            msg = BLANK_MESSAGE;
        }
        Log.d(tag, msg);
    }
    public static void infLog(String tag, String msg) {
        if (msg == null) {
            msg = BLANK_MESSAGE;
        }
        Log.i(tag, msg);
    }
}
