package com.pscomp.autoapp.monstertaiming;

import com.pscomp.autoapp.monstertaiming.MTConstants.MTIndicator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class BasicSettingActivity extends BaseActivity {
    public static final String TAG = "BasicSettingActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_basic_setting);

        inflateViews();
        setEventListeners();
        setBackIntent(MTIndicator.DEVICE_NEXUS4, MTIndicator.TYPE_DEFAULT);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void inflateViews() {
        super.inflateViews();
    }

    @Override
    protected void setEventListeners() {
        super.setEventListeners();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}
